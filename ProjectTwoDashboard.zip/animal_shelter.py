from pymongo import MongoClient
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,username,password):
        #self.client = MongoClient('mongodb://localhost:40538')
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:40538/?authMechanism=DEFAULT&authSource=AAC' % (username,password))
        #self.client = MongoClient('mongodb://%s:%s@localhost:40538' % (username, password))
        self.database = self.client['AAC']


# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary  
            return True
        else:
            return False

# Create method to implement the R in CRUD. 
    def read_all(self,data):
        cursor = self.database.animals.find(data, {'_id':False})
        return cursor
    
    def read(self,data):
        return self.database.animals.find_one(data)
    
    
#Update Method
    def update(self,data,new_data):
        if data is not None:
            updated = self.database.animals.update_many(data,new_data)
            return new_data#returns JSON
        else:
            raise Exception("Nothing to update, because data parameter is empty")
        
#Delete Method
    def delete(self,data):
        if data is not None:
            self.database.animals.delete_many(data)
            return True
        else:
            return False